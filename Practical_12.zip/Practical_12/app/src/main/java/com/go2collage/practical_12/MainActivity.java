package com.go2collage.practical_12;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText ed1, ed2;
    private Button plus, minus, div, mul, mod;
    private TextView calResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed1 = findViewById(R.id.edNum1);
        ed2 = findViewById(R.id.edNum2);
        plus = findViewById(R.id.btnPlus);
        minus = findViewById(R.id.btnMinus);
        div = findViewById(R.id.btnDivider);
        mul = findViewById(R.id.btnMul);
        mod = findViewById(R.id.btnMod);
        calResult = findViewById(R.id.txtResult);

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float result = n1 + n2;
                calResult.setText("Addition is: "+ result);
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float result = n1 - n2;
                calResult.setText("Subtraction is: "+ result);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float result = n1 / n2;
                calResult.setText("Division is: "+ result);
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float result = n1 * n2;
                calResult.setText("Multiplication is: "+ result);
            }
        });

        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float n1 = Float.parseFloat(ed1.getText().toString());
                float n2 = Float.parseFloat(ed2.getText().toString());
                float result = n1 % n2;
                calResult.setText("Percentage is: "+ result);
            }
        });

    }



}